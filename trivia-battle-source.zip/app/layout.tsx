import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Trivia Battle · Bring your people. Bring your brain.", description: "A quick-fire trivia night for friends. Create a room, share the code, and play together." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }

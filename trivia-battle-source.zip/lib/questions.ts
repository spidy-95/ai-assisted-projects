export const questions = [
{category:"SPACE",q:"Which planet has the most prominent ring system?",options:["Mars","Saturn","Venus","Mercury"],answer:1,fact:"Saturn’s bright rings are made mostly of pieces of ice."},
{category:"ANIMALS",q:"How many hearts does an octopus have?",options:["One","Two","Three","Four"],answer:2,fact:"Two hearts pump blood to the gills; the third pumps it to the body."},
{category:"GEOGRAPHY",q:"Which country is home to the city of Kyoto?",options:["China","South Korea","Thailand","Japan"],answer:3,fact:"Kyoto served as Japan’s capital for over a thousand years."},
{category:"FOOD",q:"Which ingredient is the main base of traditional hummus?",options:["Chickpeas","Lentils","Potatoes","Peas"],answer:0,fact:"Chickpeas are blended with tahini, lemon juice, and other ingredients."},
{category:"SCIENCE",q:"What is the chemical symbol for gold?",options:["Ag","Go","Au","Gd"],answer:2,fact:"Au comes from the Latin word aurum."},
{category:"SPORT",q:"How many players from one team are on court in basketball?",options:["Four","Five","Six","Seven"],answer:1,fact:"Each basketball team has five players on the court."},
{category:"NATURE",q:"What process lets plants turn sunlight into chemical energy?",options:["Evaporation","Fermentation","Condensation","Photosynthesis"],answer:3,fact:"Photosynthesis uses light energy to help make sugars."},
{category:"MUSIC",q:"Which instrument usually has 88 keys?",options:["Piano","Violin","Trumpet","Flute"],answer:0,fact:"A standard modern piano has 52 white keys and 36 black keys."},
{category:"WORLD",q:"Which ocean is the largest?",options:["Atlantic","Indian","Pacific","Arctic"],answer:2,fact:"The Pacific Ocean covers more area than any other ocean."},
{category:"TECH",q:"What does the H in HTML stand for?",options:["Hybrid","HyperText","Hosted","High"],answer:1,fact:"HTML stands for HyperText Markup Language."},
{category:"ANIMALS",q:"Which is the largest living land animal?",options:["Giraffe","African elephant","Hippopotamus","White rhinoceros"],answer:1,fact:"African elephants are the largest living land animals."},
{category:"GEOGRAPHY",q:"What is the capital of Australia?",options:["Sydney","Melbourne","Canberra","Perth"],answer:2,fact:"Canberra is Australia’s capital city."},
{category:"SCIENCE",q:"At sea level, water freezes at what temperature in Celsius?",options:["0°","10°","32°","100°"],answer:0,fact:"Pure water freezes at 0°C under standard atmospheric pressure."},
{category:"SPACE",q:"What is the closest star to Earth?",options:["Sirius","Polaris","Proxima Centauri","The Sun"],answer:3,fact:"The Sun is about 150 million kilometers from Earth."},
{category:"ART",q:"Who painted the Mona Lisa?",options:["Claude Monet","Leonardo da Vinci","Pablo Picasso","Vincent van Gogh"],answer:1,fact:"Leonardo da Vinci painted the Mona Lisa during the Renaissance."}
];
